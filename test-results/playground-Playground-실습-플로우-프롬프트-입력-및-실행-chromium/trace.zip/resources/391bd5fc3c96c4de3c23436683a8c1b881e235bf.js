(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_playground_page_tsx_082aca._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_playground_page_tsx_082aca._.js",
  "chunks": [
    "static/chunks/src_d9ee53._.js",
    "static/chunks/node_modules_micromark-core-commonmark_dev_lib_a91d55._.js",
    "static/chunks/node_modules_0cee38._.js"
  ],
  "source": "dynamic"
});
