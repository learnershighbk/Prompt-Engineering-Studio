(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_learn_[slug]_page_tsx_082aca._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_learn_[slug]_page_tsx_082aca._.js",
  "chunks": [
    "static/chunks/src_b5c62e._.js",
    "static/chunks/node_modules_micromark-core-commonmark_dev_lib_a91d55._.js",
    "static/chunks/node_modules_axios_a23d19._.js",
    "static/chunks/node_modules_@radix-ui_c1a997._.js",
    "static/chunks/node_modules_8b4927._.js"
  ],
  "source": "dynamic"
});
