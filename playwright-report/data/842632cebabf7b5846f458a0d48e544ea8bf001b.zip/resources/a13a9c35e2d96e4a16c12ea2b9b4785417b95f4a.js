(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_layout_tsx_61af54._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_layout_tsx_61af54._.js",
  "chunks": [
    "static/chunks/src_app_globals_b80590.css",
    "static/chunks/node_modules_ab25ee._.js",
    "static/chunks/src_f9daab._.js",
    "static/chunks/node_modules_@supabase_node-fetch_browser_f7ffb7.js"
  ],
  "source": "dynamic"
});
